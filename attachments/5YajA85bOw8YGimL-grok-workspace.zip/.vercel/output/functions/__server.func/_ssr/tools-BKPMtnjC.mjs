import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as getTechnique, g as getModule, l as useOrbit, s as localDate } from "./router-khs4Yp9l.mjs";
import { i as Panel } from "./bits-CB_DBJCD.mjs";
import { t as aiStatus } from "./ai.functions-a98MZAb2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-BKPMtnjC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ToolsPage() {
	const navigate = useNavigate();
	const items = useOrbit((s) => s.items);
	const custom = useOrbit((s) => s.customTechniques);
	const [modelOn, setModelOn] = (0, import_react.useState)(null);
	const [role, setRole] = (0, import_react.useState)("مربی مبتدی");
	const [task, setTask] = (0, import_react.useState)("");
	const [limit, setLimit] = (0, import_react.useState)("حداکثر ۱۵۰ کلمه، بدون توصیهٔ دستکاری");
	const [shape, setShape] = (0, import_react.useState)("تعریف، مثال، یک تمرین");
	const today = localDate();
	const due = Object.entries(items).filter(([, item]) => item.nextReview && item.nextReview <= today);
	(0, import_react.useEffect)(() => {
		aiStatus().then((res) => setModelOn(res.available)).catch(() => setModelOn(false));
	}, []);
	const prompt = [
		`نقش: ${role}`,
		`کار: ${task || "…"}`,
		`محدودیت: ${limit}`,
		`قالب: ${shape}`
	].join("\n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold",
				children: "ابزارها"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-7 text-muted",
				children: "سه ابزار همین نسخه کار می‌کنند: کارگاه پرامپت، صف مرور، و وضعیت درگاه مدل. اتوماسیون بیرونی به نسخهٔ بعد موکول شده."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "کارگاه پرامپت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نقش",
						value: role,
						onChange: setRole
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "کار",
						value: task,
						onChange: setTask,
						placeholder: "مثلاً فرق مرز و تهدید را برای دوست توضیح بده"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "محدودیت",
						value: limit,
						onChange: setLimit
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "قالب خروجی",
						value: shape,
						onChange: setShape
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "whitespace-pre-wrap rounded-xl bg-bg p-3 text-sm leading-7",
						children: prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg",
						onClick: () => {
							sessionStorage.setItem("orbit-draft", prompt);
							navigate({ to: "/assistant" });
						},
						children: "بردن به دستیار"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "مرورهای سررسید"
					}),
					due.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "موردی برای امروز نیست. بعد از تمرین نوشتاری، فاصلهٔ مرور تنظیم می‌شود."
					}),
					due.map(([id]) => {
						const title = id.startsWith("mod:") ? getModule(id.slice(4))?.module.title : getTechnique(id.slice(5), custom)?.fa;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: title ?? id
						}, id);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-2 text-sm leading-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "درگاه مدل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ارائه‌دهندهٔ محلی: دانشنامه و نمرهٔ مفهومی، همیشه روشن." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["ارائه‌دهندهٔ xAI: ", modelOn ? "Grok 4.5 آماده است و فقط با دکمه صدا زده می‌شود." : modelOn === false ? "کلید مدل در این محیط نیست." : "در حال بررسی…"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "جایگزینی مدل از استودیو توصیف شده؛ افزودن ارائه‌دهندهٔ تازه بدون بازنویسی درس‌ها طراحی شده، اما در این نسخه فقط همین دو مسیر فعال است."
					})
				]
			})
		]
	});
}
function Field({ label, value, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			placeholder,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 h-11 w-full rounded-xl border border-border bg-bg px-3 outline-none"
		})]
	});
}
//#endregion
export { ToolsPage as component };
