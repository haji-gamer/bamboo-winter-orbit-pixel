import { i as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as getTechnique, c as stageOf, g as getModule, l as useOrbit, o as achievementDefs, s as localDate, v as levelFor, w as stageNames } from "./router-khs4Yp9l.mjs";
import { i as Panel, s as faNum } from "./bits-CB_DBJCD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-HDl4uYSC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const snapshot = useOrbit();
	const setName = useOrbit((s) => s.setName);
	const xp = useOrbit((s) => s.xp);
	const streak = useOrbit((s) => s.streak);
	const items = useOrbit((s) => s.items);
	const custom = useOrbit((s) => s.customTechniques);
	const resetItem = useOrbit((s) => s.resetItem);
	const resetMemory = useOrbit((s) => s.resetMemory);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const level = levelFor(xp);
	const rows = Object.entries(items).sort((a, b) => stageOf(b[1]) - stageOf(a[1]));
	const today = localDate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold",
				children: "پروفایل و پیشرفت"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-7 text-muted",
				children: "حافظهٔ آموزشی از گفت‌وگوها جداست. می‌توانی هر مورد را پاک کنی. حساب ابری در این نسخه نیست؛ داده روی همین دستگاه است."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["نام نمایشی", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: snapshot.name,
						onChange: (e) => setName(e.target.value.slice(0, 32)),
						className: "mt-1 h-11 w-full rounded-xl border border-border bg-bg px-3 outline-none"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: level.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "num",
							children: [faNum(xp), " امتیاز"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-2 rounded-full bg-elevated",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 rounded-full bg-primary",
							style: { width: `${Math.round(level.into * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted",
						children: ["رشته: ", streak ? `${faNum(streak)} روز` : "هنوز شروع نشده"]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "دستاوردها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: achievementDefs(snapshot).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-bg px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: item.ok ? "text-accent" : "text-muted",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: item.detail
						})]
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "حافظهٔ آموزشی"
					}),
					rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "هنوز موردی ثبت نشده."
					}),
					rows.map(([id, item]) => {
						const mod = id.startsWith("mod:") ? getModule(id.slice(4)) : null;
						const tech = id.startsWith("tech:") ? getTechnique(id.slice(5), custom) : null;
						const title = mod?.module.title ?? tech?.fa ?? id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 border-b border-border py-2 text-sm last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									stageNames[stageOf(item)],
									item.nextReview ? ` · مرور ${item.nextReview === today ? "امروز" : item.nextReview}` : "",
									item.errors ? ` · ${faNum(item.errors)} خطا` : ""
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => resetItem(id),
								className: "min-h-11 rounded-lg px-2 text-xs text-muted",
								children: "حذف این مورد"
							})]
						}, id);
					}),
					!confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setConfirm(true),
						className: "min-h-11 text-sm text-primary",
						children: "پاک کردن پیشرفت و امتیاز"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								resetMemory();
								setConfirm(false);
							},
							className: "min-h-11 rounded-xl bg-primary px-3 text-sm font-semibold text-primary-fg",
							children: "بله، پیشرفت پاک شود"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirm(false),
							className: "min-h-11 rounded-xl border border-border px-3 text-sm",
							children: "انصراف"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "یادداشت‌ها، گفت‌وگوها و تکنیک‌های سفارشی با این دکمه پاک نمی‌شوند."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/library",
						className: "text-primary",
						children: "کتابخانه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools",
						className: "text-primary",
						children: "ابزارها"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "text-primary",
						children: "استودیو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/analyze",
						className: "text-primary",
						children: "تحلیل"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-6 text-muted",
				children: "نسخهٔ ۱ شامل آکادمی نه حوزه، بانک تکنیک، تمرین با نمرهٔ محلی، دستیار، تحلیل مکالمه، مرور فاصله‌دار ساده، و افزودن تکنیک بدون تغییر کد است. اتصال تلگرام و حساب چندکاربره در این نسخه نیست."
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
