//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CrmSLC3i.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/academy",
			"/admin",
			"/analyze",
			"/assistant",
			"/library",
			"/placement",
			"/profile",
			"/techniques",
			"/tools",
			"/learn/$moduleId",
			"/technique/$techniqueId"
		],
		preloads: [
			"/assets/index-DKBqkC_f.js",
			"/assets/cn-DxAXDXZV.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-HJQXq8Oh.js",
			"/assets/preload-helper-CQLraRdH.js",
			"/assets/useRouter-C8kNhW7W.js",
			"/assets/useNavigate-DdHhJ9dI.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DKBqkC_f.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BWjPwPAV.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/academy": {
		filePath: "/workspace/src/routes/academy.tsx",
		children: ["/academy/$domainId"],
		preloads: ["/assets/academy-BeiHtei-.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-D-84dLgB.js",
			"/assets/ai.functions-BtbitWaT.js",
			"/assets/bits-DQ50nVBe.js"
		]
	},
	"/analyze": {
		filePath: "/workspace/src/routes/analyze.tsx",
		children: void 0,
		preloads: [
			"/assets/analyze-B9RqunKz.js",
			"/assets/ai.functions-BtbitWaT.js",
			"/assets/bits-DQ50nVBe.js"
		]
	},
	"/assistant": {
		filePath: "/workspace/src/routes/assistant.tsx",
		children: void 0,
		preloads: [
			"/assets/assistant-CR_gW09U.js",
			"/assets/ai.functions-BtbitWaT.js",
			"/assets/bits-DQ50nVBe.js"
		]
	},
	"/library": {
		filePath: "/workspace/src/routes/library.tsx",
		children: void 0,
		preloads: ["/assets/library-8Lf9BflO.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/placement": {
		filePath: "/workspace/src/routes/placement.tsx",
		children: void 0,
		preloads: ["/assets/placement-BRboQHG0.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-Dsv1UN3o.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/techniques": {
		filePath: "/workspace/src/routes/techniques.tsx",
		children: void 0,
		preloads: ["/assets/techniques-qn7BXwsI.js", "/assets/bits-DQ50nVBe.js"]
	},
	"/tools": {
		filePath: "/workspace/src/routes/tools.tsx",
		children: void 0,
		preloads: [
			"/assets/tools-C_Hexg3m.js",
			"/assets/ai.functions-BtbitWaT.js",
			"/assets/bits-DQ50nVBe.js"
		]
	},
	"/academy/$domainId": {
		filePath: "/workspace/src/routes/academy.$domainId.tsx",
		children: void 0,
		preloads: ["/assets/academy._domainId-CobQFod0.js"]
	},
	"/learn/$moduleId": {
		filePath: "/workspace/src/routes/learn.$moduleId.tsx",
		children: void 0,
		preloads: [
			"/assets/learn._moduleId-B5hCAVnZ.js",
			"/assets/bits-DQ50nVBe.js",
			"/assets/practice-g4Xys382.js"
		]
	},
	"/technique/$techniqueId": {
		filePath: "/workspace/src/routes/technique.$techniqueId.tsx",
		children: void 0,
		preloads: [
			"/assets/technique._techniqueId-C1cN0voI.js",
			"/assets/bits-DQ50nVBe.js",
			"/assets/practice-g4Xys382.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
