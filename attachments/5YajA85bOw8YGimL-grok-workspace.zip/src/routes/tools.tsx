import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { aiStatus } from "@/lib/ai.functions";
import { Panel } from "@/components/bits";
import { localDate, useOrbit } from "@/lib/store";
import { getModule, getTechnique } from "@/data/catalog";

export const Route = createFileRoute("/tools")({
  head: () => ({ meta: [{ title: "ابزارها · ORBIT" }] }),
  component: ToolsPage,
});

function ToolsPage() {
  const navigate = useNavigate();
  const items = useOrbit((s) => s.items);
  const custom = useOrbit((s) => s.customTechniques);
  const [modelOn, setModelOn] = useState<boolean | null>(null);
  const [role, setRole] = useState("مربی مبتدی");
  const [task, setTask] = useState("");
  const [limit, setLimit] = useState("حداکثر ۱۵۰ کلمه، بدون توصیهٔ دستکاری");
  const [shape, setShape] = useState("تعریف، مثال، یک تمرین");
  const today = localDate();
  const due = Object.entries(items).filter(([, item]) => item.nextReview && item.nextReview <= today);

  useEffect(() => {
    void aiStatus().then((res) => setModelOn(res.available)).catch(() => setModelOn(false));
  }, []);

  const prompt = [`نقش: ${role}`, `کار: ${task || "…"}`, `محدودیت: ${limit}`, `قالب: ${shape}`].join("\n");

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <header>
        <h1 className="text-3xl font-bold">ابزارها</h1>
        <p className="mt-2 text-sm leading-7 text-muted">سه ابزار همین نسخه کار می‌کنند: کارگاه پرامپت، صف مرور، و وضعیت درگاه مدل. اتوماسیون بیرونی به نسخهٔ بعد موکول شده.</p>
      </header>
      <Panel className="space-y-3">
        <h2 className="font-semibold">کارگاه پرامپت</h2>
        <Field label="نقش" value={role} onChange={setRole} />
        <Field label="کار" value={task} onChange={setTask} placeholder="مثلاً فرق مرز و تهدید را برای دوست توضیح بده" />
        <Field label="محدودیت" value={limit} onChange={setLimit} />
        <Field label="قالب خروجی" value={shape} onChange={setShape} />
        <pre className="whitespace-pre-wrap rounded-xl bg-bg p-3 text-sm leading-7">{prompt}</pre>
        <button
          type="button"
          className="min-h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg"
          onClick={() => {
            sessionStorage.setItem("orbit-draft", prompt);
            void navigate({ to: "/assistant" });
          }}
        >
          بردن به دستیار
        </button>
      </Panel>
      <Panel className="space-y-2">
        <h2 className="font-semibold">مرورهای سررسید</h2>
        {due.length === 0 && <p className="text-sm text-muted">موردی برای امروز نیست. بعد از تمرین نوشتاری، فاصلهٔ مرور تنظیم می‌شود.</p>}
        {due.map(([id]) => {
          const title = id.startsWith("mod:") ? getModule(id.slice(4))?.module.title : getTechnique(id.slice(5), custom)?.fa;
          return <p key={id} className="text-sm">{title ?? id}</p>;
        })}
      </Panel>
      <Panel className="space-y-2 text-sm leading-7">
        <h2 className="font-semibold">درگاه مدل</h2>
        <p>ارائه‌دهندهٔ محلی: دانشنامه و نمرهٔ مفهومی، همیشه روشن.</p>
        <p>ارائه‌دهندهٔ xAI: {modelOn ? "Grok 4.5 آماده است و فقط با دکمه صدا زده می‌شود." : modelOn === false ? "کلید مدل در این محیط نیست." : "در حال بررسی…"}</p>
        <p className="text-muted">جایگزینی مدل از استودیو توصیف شده؛ افزودن ارائه‌دهندهٔ تازه بدون بازنویسی درس‌ها طراحی شده، اما در این نسخه فقط همین دو مسیر فعال است.</p>
      </Panel>
    </div>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block text-sm">
      {label}
      <input value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className="mt-1 h-11 w-full rounded-xl border border-border bg-bg px-3 outline-none" />
    </label>
  );
}
